rm=list()
# Analisis de texto: https://www.tidytextmining.com/tidytext
#----------------------------------------------------
# Ruta de carpeta
#----------------------------------------------------
path     <- "C:/Users/et396/Dropbox"
estudios <- "Docencia/Educate/Taller"
figura   <- "Imagen"
data     <- "Data/m1"

#----------------------------------------------------
# Librerias
#----------------------------------------------------
paquetes_set <- c("readstata13", "dplyr", "tidyverse", "mfx",
                  "survey", "stargazer", "caret", "foreign",
                  "stargazer", "texreg", "sjPlot","margins",
                  "tm","SnowballC","wordcloud","RColorBrewer",
                  "stopwords","wordcloud2","tidytext","pdftools")
# install.packages(paquetes_set)
lapply(paquetes_set, library, character.only=TRUE)

# Informacion planes de gobierno
# ====================================================
# Paso 1
# ====================================================
raw_text1 <- pdf_text(paste0(path,"/",
                       estudios,"/",
                       data,"/",
                       "ALIANZA PARA EL PROGRESO ERM 2015-2018.pdf"))

raw_text2 <- pdf_text(paste0(path,"/",
                            estudios,"/",
                            data,"/",
                            "3017.pdf"))

raw_text3 <- pdf_text(paste0(path,"/",
                             estudios,"/",
                             data,"/",
                             "plan-bicentenario.pdf"))

# Paso 2
# ====================================================
# https://www.youtube.com/watch?v=_IdmMYKZOtA
content1 <- unlist(raw_text1)
content2 <- unlist(raw_text2)
content3 <- unlist(raw_text3)

# Paso 3
# ====================================================
# change in dataframe
data1 <- data.frame(text=content1)
data2 <- data.frame(text=content2)
data3 <- data.frame(text=content3)

# Paso 4
# ====================================================
# chamnge in format word
tidy_pdf1 <- data1 %>% 
  unnest_tokens(word,text)

tidy_pdf2 <- data2 %>% 
  unnest_tokens(word,text)

tidy_pdf3 <- data3 %>% 
  unnest_tokens(word,text)
# Paso 5
# ====================================================
# Stop words
# http://jvera.rbind.io/post/2017/10/16/spanish-stopwords-for-tidytext-package/
custom_stop_words <- bind_rows(stop_words,
                               data_frame(word = tm::stopwords("spanish"),
                                          lexicon = "custom"))

# Paso 6
# ====================================================
# Filtrar stopwords (espanol)
tidy_base1 <- tidy_pdf1 %>% 
  filter(!word %in% custom_stop_words$word)

tidy_base2 <- tidy_pdf2 %>% 
  filter(!word %in% custom_stop_words$word)

tidy_base3 <- tidy_pdf3 %>% 
  filter(!word %in% custom_stop_words$word)

# Paso 7
# ====================================================
# Filtrar numeros
tidy_base1s <- tidy_base1 %>%
  filter(!str_detect(word, "\\d"))

tidy_base2s <- tidy_base2 %>%
  filter(!str_detect(word, "\\d"))

tidy_base3s <- tidy_base3 %>%
  filter(!str_detect(word, "\\d"))

# Paso 8
# ====================================================
# Contabilidad de palabras mas repetidas
# tidy_base1s %>%  count(word, sort = TRUE)
tidy_base1s %>%  
  count(word, sort = TRUE) %>% 
  filter(n>100) 

tidy_base2s %>%  
  count(word, sort = TRUE) %>% 
  filter(n>50) 

tidy_base3s %>%  
  count(word, sort = TRUE) %>% 
  filter(n>10)

# Paso 9
# Visuzalizacion 
# ======================================================
# General
library(ggplot2)

tidy_base1s %>%
  count(word) %>%
  filter(n>100) %>% 
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n)) +
  geom_bar(stat = "identity", color = "black", fill = "#87CEFA") +
  geom_text(aes(hjust = 1, label = n)) + 
  coord_flip() + 
  labs(title = "",  x = "Palabras", y = "Número de usos")
ggsave(paste0(path,"/", estudios,"/",figura,"/","app.png"))

tidy_base2s %>%
  count(word) %>%
  filter(n>50) %>% 
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n)) +
  geom_bar(stat = "identity", color = "black", fill = "#87CEFA") +
  geom_text(aes(hjust = 1, label = n)) + 
  coord_flip() + 
  labs(title = "",  x = "Palabras", y = "Número de usos")
ggsave(paste0(path,"/", estudios,"/",figura,"/","keiko.png"))

tidy_base3s %>%
  count(word) %>%
  filter(n>10) %>% 
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n)) +
  geom_bar(stat = "identity", color = "black", fill = "#87CEFA") +
  geom_text(aes(hjust = 1, label = n)) + 
  coord_flip() + 
  labs(title = "",  x = "Palabras", y = "Número de usos")
ggsave(paste0(path,"/", estudios,"/",figura,"/","pedro.png"))

#===================================================================
# Graficos de Dispersion
#===================================================================
# Informacion 
tidy_base3s <- tidy_base3s %>% mutate(rpartido= "pedrocastillo")
tidy_base2s <- tidy_base2s %>% mutate(rpartido= "fuerzapolular")
tidy_base1s <- tidy_base1s %>% mutate(rpartido= "app")

base_combine <- rbind(tidy_base1s, tidy_base2s, tidy_base3s)
base_combine <- base_combine %>% mutate(rpartido=factor(rpartido))
table(base_combine$rpartido)

# tipo de evaluacion
base_spread <- base_combine %>% group_by(rpartido, word) %>% count(word) %>%
  spread(key = rpartido, value = n, fill = NA, drop = TRUE)
base_spread %>% names()

cor.test(~ app + fuerzapolular, method = "pearson", data = base_spread)
cor.test(~ pedrocastillo + fuerzapolular, method = "pearson", data = base_spread)

library(gridExtra)
library(scales)

p1 <- ggplot(base_spread, aes(app, fuerzapolular)) +
  geom_jitter(alpha = 0.1, size = 2.5, width = 0.25, height = 0.25) +
  geom_text(aes(label = word), check_overlap = TRUE, vjust = 1.0) +
  scale_x_log10(labels = percent_format()) +
  scale_y_log10(labels = percent_format()) +
  geom_abline(color = "red") +
  theme_bw() +
  theme(axis.text.x = element_blank(),
        axis.text.y = element_blank())
p1
ggsave(paste0(path,"/", estudios,"/",figura,"/","word1.png"))

p2 <- ggplot(base_spread, aes(pedrocastillo, fuerzapolular)) +
  geom_jitter(alpha = 0.1, size = 2.5, width = 0.25, height = 0.25) +
  geom_text(aes(label = word), check_overlap = TRUE, vjust = 1.0) +
  scale_x_log10(labels = percent_format()) +
  scale_y_log10(labels = percent_format()) +
  geom_abline(color = "red") +
  theme_bw() +
  theme(axis.text.x = element_blank(),
        axis.text.y = element_blank())
p2
ggsave(paste0(path,"/", estudios,"/",figura,"/","word2.png"))


