clear all;
close all;
clc
% change folders
addpath('C:\Users\et396\OneDrive - University of Kent\Desktop\PhD_Courses\Matlab\dynare_4.5.3\4.5.3\matlab')

%% New Keyesian Model (NK) - paper
dynare model6.mod